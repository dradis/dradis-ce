ReportTemplateProperties.create_from_hash!(
  definition_file: File.basename(__FILE__, '.rb'),
  # plugin_name: 'excel',
  plugin_name: 'word',
  # plugin_name: 'html_export',
  content_block_fields: {
    'Conclusion' => [
      {name: 'Name', type: 'string', values: nil},
      {name: 'Type', type: 'string', values: 'Conclusion'},
    ],
    'Scope' => [
      {name: 'Name', type: 'string', values: nil},
      {name: 'Type', type: 'string', values: 'Scope'},
    ]
  },
  document_properties: [
    'dradis.project',
    'dradis.client',
  ],
  evidence_fields: [
    {name: 'Evidence Field 1', type: 'number', values: nil},
    {name: 'Evidence Field 2', type: 'number', values: nil},
  ],
  issue_fields: [
    {name: 'Issue Field 1', type: 'number', values: nil},
    {name: 'Issue Field 2', type: 'number', values: nil},
  ]
)
